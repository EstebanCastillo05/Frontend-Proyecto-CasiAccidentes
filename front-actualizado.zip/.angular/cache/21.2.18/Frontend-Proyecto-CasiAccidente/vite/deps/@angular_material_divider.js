import {
  MatDivider,
  MatDividerModule
} from "./chunk-CWDJE3FF.js";
import "./chunk-42QFQP6S.js";
import "./chunk-N4DOILP3.js";
import "./chunk-NJWZL2IW.js";
import "./chunk-A5KFWV2Z.js";
import "./chunk-T2GKPQEW.js";
import "./chunk-J46EEYGT.js";
import "./chunk-4YCCEXQQ.js";
import "./chunk-U7EDC2PH.js";
export {
  MatDivider,
  MatDividerModule
};
