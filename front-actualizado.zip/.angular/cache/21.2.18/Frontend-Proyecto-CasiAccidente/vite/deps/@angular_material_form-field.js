import {
  MatFormFieldModule
} from "./chunk-4VW2ACMH.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-YCHA34U7.js";
import "./chunk-WZ5T2WXV.js";
import "./chunk-WQWUZF6D.js";
import "./chunk-42QFQP6S.js";
import "./chunk-UN652PWY.js";
import "./chunk-SVLHAV3T.js";
import "./chunk-Y2MDIKXU.js";
import "./chunk-N4DOILP3.js";
import "./chunk-SI62FSGI.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-NJWZL2IW.js";
import "./chunk-A5KFWV2Z.js";
import "./chunk-DRJXOLMQ.js";
import "./chunk-FPP7TEFJ.js";
import "./chunk-NB536JGV.js";
import "./chunk-ZZ2EXBL5.js";
import "./chunk-T2GKPQEW.js";
import "./chunk-J46EEYGT.js";
import "./chunk-4YCCEXQQ.js";
import "./chunk-U7EDC2PH.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
